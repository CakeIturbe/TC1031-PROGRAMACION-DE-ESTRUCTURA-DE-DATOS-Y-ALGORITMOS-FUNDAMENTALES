# Proyecto: Repositorio Premier League
Proyecto de visualizacion de estadisticas de futbol y busqueda eficiente de jugadores.

## Descripción del avance 1
En este avance de proyecto, el programa es capaz de leer un archivo csv y ordenar sus datos dependiendo de lo que se desee ordenar. Una vez ordenados estos datos se escriben en un archivo. Nuestro archivo csv, son los datos de la liga de futbol premier league de la temporada 2018-2019, estos datos se utilizaran para llevar a cabo ordenamiento de jugadores por mayor cantidad de goles anotados o partidos jugandos. 

## Descripción del avance 2
En este avance de proyecto, el programa además de lo ya hecho en el avance uno, se logra leer un archivo .csv y cargar sus datos a una estructura de datos. La estructura de datos a utilizar fue el arbol splay. Con el uso de la estructura se pueden realizar busquedas de jugadores rapidamente, obteniendo sugerencias de acuerdo a nuestro input y obteniendo los resultados del jugador en un archivo .csv.

### Cambios sobre el primer avance
1.

## Descripción del avance 3
Se agrego la complejidad de todas las funciones dentro de la aplicacion.

### Cambios sobre el segundo avance
1. Se cambio el cin del nombre del jugador a buscar, ya que no aceptaba espacios. Se utilizo getline y el uso de char[] para posteriormente convertir a string.

## Entrega final
Version final del proyecto. Se realizaron los cambios descritos respecto al avance 3. Se añadio otro caso de escritura en archivos. Se tiene el archivo "arbol.csv" en donde se verá la version inicial de la estructura de datos y se verán las nuevas versiones del arbol modificado conforme se vayan realizando busquedas. 

### Cambios sobre el tercer avance avance
1. Se cambio la salida de datos obtenida en el buscar jugador. En vez de que cada vez te devuelva un archivo individual con la informacion del jugador, se condensara toda la indormacion de los jugadores buscados en un mismo archivo para mayor practicidad. jugadoresBuscados.csv.  

## Instrucciones para compilar el avance de proyecto
Ejecuta el siguiente comando en la terminal:

`g++ main.cpp -o primer_avance` 

## Instrucciones para ejecutar el avance de proyecto
Ejecuta el siguiente comando en la terminal:

`./primer_avance` 

## Descripción de las entradas del avance de proyecto
El proyecto toma como entrada un archivo .csv, en nuestro caso el archivo csv es el registro de la Liga Inglesa de futbol de la temporada 2018-2019. Algunos de los datos del archivo incluyen nombre de los jugadores, goles anotados, minutos jugados, equipo, entre otros. 

## Descripción de las salidas del avance de proyecto
Los resultados del primer avance te muestran las estadisticas de los jugadores durante el campeonato en la consola. Las salidas son los goleadores de la competicion, maximos asistentes, y mas minutos jugados, en orden ascendente o descendente. <br>
Los resultados del segundo avance se muestran en un archivo .csv. Son las estadisticas del jugador buscado. El archivo se llamara "nombre del jugador".csv. Si realizas varias busquedas de diferentes jugadores, obtendras varios archivos de salida.


## Desarrollo de competencias

### SICT0301: Evalúa los componentes
#### Hace un análisis de complejidad correcto y completo para los algoritmos de ordenamiento usados en el programa.
El algoritmo de ordenamiento de Busqueda Bubble cuenta con una complejidad de O(n^2).

#### Hace un análisis de complejidad correcto y completo de todas las estructuras de datos y cada uno de sus usos en el programa.
La estructura de datos de Arbol Splay tiene una complejidad de O(n). Se utiliza dentro de la clase la funcion de Suggest(), el cual tiene una complejidad de O(n*m).

#### Hace un análisis de complejidad correcto y completo para todos los demás componentes del programa y determina la complejidad final del programa.
Se calculo la complejidad para todas las funciones del programa y se obtuvo una complejidad final de la aplicacion de O(n^2). Los registros de complejidad de las funciones se encuentran comentadas antes de las funciones en el codigo.

### SICT0302: Toma decisiones
#### Selecciona un algoritmo de ordenamiento adecuado al problema y lo usa correctamente.
El algoritmo de ordenamiento utilizado es Bubble Sort y se encuentra en el archivo sorts.h. Su complejidad es O(n^2), y se utilizo debido a su implementacion simple y a que es util para cargas de datos pequeñas.

#### Selecciona una estructura de datos adecuada al problema y la usa correctamente.
La estructura de datos utilizada fue un arbol splay y se encuentra en el archivo splay.h. Su complejidad es O(n), y se utilizo ya que se queria para eficientar la busqueda priorizando el nodo accedido mas reciente.


### SICT0303: Implementa acciones científicas
#### Implementa mecanismos para consultar información de las estructras correctos.
El proyecto cuenta con mecanismos donde consultamos la informacion del arbol splay, como se hace en la opcion de Buscar Jugador. Aqui obtendremos sugerencias que se consultan en el arbol y posteriormente consultamos la informacion del jugador en el arbol aplicando el metodo find() el cual lleva consigo el splay() del arbol. 

#### Implementa mecanismos de lectura de archivos para cargar datos a las estructuras de manera correcta.
Cargué los datos del archivo a el arbol utilizando lectura linea por linea y obteniendo la columna de nombres. El arbol tiene como value el nombre del jugador convertido a string, utilizando la funcion getStringValue(), el cual se utilizo para insertar el nodo al arbol. Además, cuenta con name que es le nombre del jugador, y un string content que tiene cargada la linea con todos los datos del jugador.

### Implementa mecanismos de escritura de archivos para guardar los datos  de las estructuras de manera correcta
Hice escritura en archivos en el programa cuando buscas un jugador, se exportarán sus datos obtenidos a un archivo .csv con su nombre (p.e. "Alexis Sanchez.csv"). <br>
**CAMBIOS:**<br> Se realizaron cambios en la escritura del archivo para mayor practicidad para el usuario. Ahora los datos de los jugadores buscados se encuentran en un mismo archivo "jugadoresBuscados.csv"<br>
Se añadio el archivo arbol.csv, en el cual se escribe un print del arbol en su version orginal al abrir el programa. Y posteriormente se van añadiendo las versiones modificadas conforme se van realizando busquedas.
