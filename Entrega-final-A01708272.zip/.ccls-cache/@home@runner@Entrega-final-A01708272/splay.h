#ifndef Splay_H_
#define Splay_H_

#include <string>
#include <vector>
#include <sstream>
#include "exception.h"
#include <iostream>
using namespace std;

template <class T>class SplayTree;

template <class T>
class Node {
private:
  T value;
  string name;
  string content;
  Node *left, *right, *parent;
public:
  Node(T val) : value(val), name(""), content(""), left(0), right(0), parent(nullptr) {}
  Node(T val, string nm, string cont, Node<T> *le, Node<T> *ri, Node<T> *par )
    : value(val), name(nm), content(cont), left(le), right(ri), parent(par) {}
  friend class SplayTree<T>;
  void print_tree(std::stringstream &) const;
};

template <class T>
class SplayTree {
private:
 Node<T>* root=nullptr;
  int sze;
public:
  SplayTree(){
    root=nullptr;
    sze = 0;
  } 

  void rot_right(Node<T>*);//
  void rot_left(Node<T>*);//
  void splay(Node<T>*); //
  Node<T>* new_node(T, string, string); //
  void add(T, string, string); //
  string find(T); //
  vector<string> suggest(string); //
  void suggest(Node<T>*, string, vector<string> &);//
  int size();
  string getRoot();
  stringstream printTree() const; //
};

//Complejidad : O(1)
template <class T>
Node<T>* SplayTree<T>::new_node(T val, string name, string cont){
  Node<T>* p_node = new Node<T>(val);
  p_node -> name = name;
  p_node -> content = cont;
  if(p_node == NULL)
    throw NoSuchElement();
  
  return p_node;
}

//Complejidad : O(n)
template <class T>
void Node<T>::print_tree(std::stringstream &aux) const {
  if (parent != 0){
    aux << "\n node " << value << " name: " << name;
    aux << " parent " << parent->value;
  }else
    aux << "\n root " << value << " name: " << name;
  if (left != 0)
    aux << " left " << left->value;
  if (right != 0)
    aux << " right " << right->value;
  aux << "\n";

  if (left != 0) {
    left->print_tree(aux);
  }
  if (right != 0) {
    right->print_tree(aux);
  }
}

template <class T>
stringstream SplayTree<T>::printTree() const{
  std::stringstream aux;
  if (sze > 0) {
     root->print_tree(aux);
  }
  return aux;
    //aux.str();
}


//Complejidad : O(n)
template <class T>
void SplayTree<T>::add(T val, string name, string cont) {
  Node<T>* n  = new_node(val, name, cont);
  Node<T>* temp = root;
  Node<T>* y = nullptr;
  while (temp != nullptr){
    y = temp;
    if (n->value < temp->value)
      temp = temp->left;
    else 
      temp = temp->right;
  }
  n->parent = y;
  if (y == nullptr) 
    root = n;
  else if (n -> value < y -> value){
    y -> left = n;
  }
    
  else {
    y -> right = n;
  }
  sze++;
  splay(n);
}

//Complejidad : O(n)
template <class T>
void SplayTree<T>::splay(Node<T>* val){
  while (val->parent){
    if (val -> parent == root){
      if (val == val->parent->left)
        rot_right(val->parent);
      else rot_left(val->parent);
    }

    else if(val==val->parent->left && val->parent==val->parent->parent->left){//Zig Zig 
        rot_right(val->parent->parent);
        rot_right(val->parent);
    }else if(val== val->parent->right && val->parent==val->parent->parent->right){//zag zag
      rot_left(val->parent->parent);
      rot_left(val->parent);
    }else if(val==val->parent->left && val->parent == val->parent->parent->right){
          rot_right(val->parent);
          rot_left(val->parent);
    }else if(val== val->parent->right && val->parent== val->parent->parent->left){
        rot_left(val->parent);
        rot_right(val->parent);
    }
  }
}

//Complejidad : O(1)
template <class T>
void SplayTree<T>::rot_right(Node<T>* x){
  Node<T>* y = x->left;
  x->left = y->right;
  if(y->right){
      y->right->parent=x;
  }
  y->parent = x-> parent;
  if(x->parent==nullptr){
    root=y;
  }else if(x==x->parent->left){
    x->parent->left=y;
  }else if(x== x->parent->right){
    x->parent->right=y;
  }
  y->right=x;
  x->parent=y;
}

//Complejidad : O(1)
template <class T>
void SplayTree<T>::rot_left(Node<T>* x){
  Node<T>* y = x->right;
  x->right = y->left;
  if(y->left){
      y->left->parent=x;
  }
  y->parent = x-> parent;
  if(x->parent==nullptr){
    root=y;
  }else if(x==x->parent->right){
    x->parent->right=y;
  }else if(x== x->parent->left){
    x->parent->left=y;
  }
  y->left=x;
  x->parent=y;
}

//Complejidad : O(n)
template <class T>
string SplayTree<T>::find(T x) {
  Node<T>* n  = new_node(x,"","");
  Node<T>* temp = root;
  Node<T>* y = nullptr;
  while (temp != nullptr){
    if (n->value == temp->value){
      splay(temp);
      return temp->content;
    } 
    y = temp;
    if (n->value < temp->value)
      temp = temp->left;
    else 
      temp = temp->right;
  }
  splay(y);
  return y->content;
}


//Funcion que obtiene una entrada y que lo va comparando con los nombres existentes de el arbol
//Complejidad : O(n*m)
template <class T>
void SplayTree<T>::suggest(Node<T> *node, string entrada, vector<string> &result){
  if (!node) {
      return;
  }
  string nombre = node ->name;
  int aux=1;
  for (int i=0; i < entrada.length(); i++){
    if(nombre[i] != entrada[i]){
      aux = 0;
      break;
    }
  }
  if (aux == 1){
    result.push_back(nombre);
    //cont++;
  } 
  suggest(node->left,entrada, result);
  suggest(node->right,entrada, result);
}

//Complejidad : O(n*m)
template <class T>
vector<string> SplayTree<T>::suggest(string entrada) {
  vector<string> result;
  suggest(root, entrada, result);
  return result;
}

//Complejidad : O(1)
template <class T>
int SplayTree<T>::size() {
  return sze;
}

//Complejidad : O(1)
template <class T>
string SplayTree<T>::getRoot(){
  return root->name;
}

#endif /* Splay_H_ */
