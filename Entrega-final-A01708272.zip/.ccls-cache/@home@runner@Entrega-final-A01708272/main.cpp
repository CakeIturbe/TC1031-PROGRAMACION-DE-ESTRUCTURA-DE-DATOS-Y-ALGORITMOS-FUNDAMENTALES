
#include <iostream>
#include <cstdio>
#include <fstream>
#include <string>
#include <vector>
#include <sstream>
#include <list>
#include <stdexcept>
#include <map>
#include "sorts.h"
#include "splay.h"
using namespace std;


// Funcion que regresa la linea deseada separada
//Complejidad : O(n^2)
vector<string> getLineSep(ifstream& inFile,int i, int limit){
	//read line by line
	vector<string> content;
	string line;
	int cont=0;
	while (!inFile.eof() && i < limit){
		i++;
		getline(inFile,line);
    //char delimiter = ",";
		if(inFile.good()){
      string aux;
      for (int y=0; y < line.size(); y++){
        if (line[y] == ',' || y == line.size() -1 ) {
          content.push_back(aux);
          aux = "";
        }
        else aux += line[y];
      } 
		}
		cont++;
	} 
	return content;
}

// Funcion que regresa los valores que contiene la columna deseada
//Complejidad : O(n^2)
vector<string> getColumn(ifstream& inFile,int i, int limit, int index){
  //read line by line
  vector<string> content;
  string line;
  int cont=0;
  int coms=0;
  inFile.seekg(0);
  while (!inFile.eof() && i <= limit){
    i++;
    getline(inFile,line);
    if(inFile.good() && cont>0){
      string aux;
      for (int y=0; y < line.size(); y++){ 
        if (line[y] == ',' ) coms++;
        if (line[y] == ',' && coms == index+1) {
          content.push_back(aux);
          aux = "";
        }
        if (coms == index && line[y] != ',' ) aux += line[y];
      } 
    }
    cont++;
    coms = 0;
  } 
  return content;
}

//Funcion que regresa el valor numerico de un nombre recibido
//Complejidad : O(n)
int getStringValue(string name){
  int acum = 0;
  for (int i = 0; i < name.size(); i++){
    acum += (int) name[i];
    acum= acum*2;
  }
  return acum;
}

// Funcion que regresa el indice de la columna deseada a partir de la busqueda del string en la linea 1
//Complejidad : O(n)
int getIndex(vector<string> linea, string header){
  for (int i=0; i < linea.size(); i++){
  	if (linea[i] == header) return i;
  }
  return -1;
}

// Funcion que hace el formato para realizar el ordenamiento y despues lo ordena llamando a bubbleSort de Sorts.h
//Complejidad : O(n)+O(n^2) => O(n^2)
vector<string> OrdenaBubble(ifstream& inFile, int index, vector<string> names, int numLines) {
  Sorts<int> sorts;
  vector<string> xToOrder = getColumn(inFile, 1, numLines, index);
  string xPlusName;
  vector<string> lista;
  vector<int> x;
  for (int i=0; i < xToOrder.size(); i++){
    xPlusName += xToOrder[i];
    xPlusName += ", ";
    xPlusName += names[i];
    lista.push_back(xPlusName);
    x.push_back(stoi(xToOrder[i]));
    xPlusName = "";
  }
  vector<string> listaOrdenada;
  listaOrdenada = sorts.bubbleSort(x, lista); //O(n^2)
  return listaOrdenada;
}

// Funcion que obtiene la cantidad de resultados que desea obtener el usuario
//Complejidad : O(n)
int getCantidadResultados(int tamanio){
  float ans=1;
  while (ans){
    cout << "\n\n===================================================\n";
    cout << "\n===                                             ===\n";
    cout << "\n===      ¿Cuantos resultados desea obtener?     ===\n";
    cout << "\n===           1. Todos ("<<tamanio<<")                    ===\n";
    cout << "\n===           2. Introducir cantidad            ===\n";
    cout << "\n===                                             ===\n";
    cout << "\n===================================================\n\n";
    cin>>ans;
    if (ans == 1){
      return tamanio;
    }
    else if (ans == 2){
      int x;
      cout << "\n\n===================================================\n";
      cout<< "Ingrese la cantidad de resultados que desea obtener:  "; 
      cin >> x; 
      if (x > tamanio) return tamanio;
      return x;
    }
    else cout << "\n=============== ¡ Opcion no valida ! ==============\n------- Vuelva a ingresar la opcion deseada -------\n";
    
  }
  return tamanio;
}
// Funcion que obtiene el orden en que se mostraran los resultados al usuario
//Complejidad : O(n)
int getOrden(){
  float ans=1;
  while (ans){
    cout << "\n\n===================================================\n";
    cout << "\n===                                             ===\n";
    cout << "\n=== ¿En que orden desea obtener sus resultados? ===\n";
    cout << "\n===           1. Mayor a menor                  ===\n";
    cout << "\n===           2. Menor a mayor                  ===\n";
    cout << "\n===                                             ===\n";
    cout << "\n===================================================\n\n";
    cin>>ans;
      if (ans == 1){
        return 1;
      }
      else if (ans == 2){
        return 2;
      }
      else cout << "\n=============== ¡ Opcion no valida ! ==============\n------- Vuelva a ingresar la opcion deseada -------\n";
  }
  return 1;
}

//Funcion que espera a que el usuario presione Enter para continuar
//Complejidad : O(1)
void awaitEnter(){
  cout << "\n\nPresiona Enter para continuar...";
  cin.ignore();
  cin.get();
}

//Complejidad : O(n^2)
void menuStats(ifstream& inFile, Sorts<int> sorts, vector<string> linea1, vector<string> nombres,int numLines){
  float ans = 0;
  int cantResults, orden;
  while (ans != 4){
   cout << "\n\n=================== ESTADISTICAS ==================\n";
   cout << "\n===================================================\n";
   cout << "\n===           1. Goles                          ===\n";
   cout << "\n===           2. Asistencias                    ===\n";
   cout << "\n===           3. Minutos jugados                ===\n";
   cout << "\n===           4. Regresar                       ===\n";
   cout << "\n===                                             ===\n";
   cout << "\n===================================================\n\n"; 
   cin >> ans;
    if( ans == 1){
      int index= getIndex(linea1, "goals_overall");
      vector<string> xToOrder = getColumn(inFile, 1, numLines, index);
      vector<string> listaOrdenada;
      listaOrdenada = OrdenaBubble(inFile, index, nombres,numLines);
      int cont =0;
      cantResults = getCantidadResultados(listaOrdenada.size());
      orden = getOrden();
      
      cout<< "\n=================== Tabla de goleo ================";
      cout<< "\nPos  Goles          Jugador";
      if (orden == 1){
        for (int i = listaOrdenada.size()-1; i >= listaOrdenada.size() - cantResults; i--){
          cont++;
          cout << "\n" << cont<< "      " <<listaOrdenada[i];
          if (cont == listaOrdenada.size()) break;
        }
      }
      if (orden == 2){
        for (int i = 0; i < cantResults; i++){
          cont++;
          cout << "\n" << cont<< "      " <<listaOrdenada[i];
        }
      }    
      awaitEnter();
    }
    else if (ans == 2){
      int index= getIndex(linea1, "assists_overall");
      vector<string> xToOrder = getColumn(inFile, 1, numLines, index);
      vector<string> listaOrdenada;
      listaOrdenada = OrdenaBubble(inFile, index, nombres, numLines);
      int cont =0;
      cantResults = getCantidadResultados(listaOrdenada.size());
      orden = getOrden();

      cout<< "\n=================== Tabla de asistencias ================";
      cout<< "\nPos Asistencias    Jugador";
      if (orden == 1){
        for (int i = listaOrdenada.size()-1; i >= listaOrdenada.size() - cantResults; i--){
          cont++;
          cout << "\n" << cont<< "      " <<listaOrdenada[i];
          if (cont == listaOrdenada.size()) break;
        }
      }
      if (orden == 2){
        for (int i = 0; i < cantResults; i++){
          cont++;
          cout << "\n" << cont<< "      " <<listaOrdenada[i];
        }
      }    
      awaitEnter();
    }
    else if (ans == 3){
      int index= getIndex(linea1, "minutes_played_overall");
      vector<string> xToOrder = getColumn(inFile, 1, numLines, index);
      vector<string> listaOrdenada;
      listaOrdenada = OrdenaBubble(inFile, index, nombres, numLines);
      int cont =0;
      cantResults = getCantidadResultados(listaOrdenada.size());
      orden = getOrden();
      cout<< "\n================ Tabla de minutos jugados ==============";
      cout<< "\nPos Minutos       Jugador";
      if (orden == 1){
        for (int i = listaOrdenada.size()-1; i >= listaOrdenada.size() - cantResults; i--){
          cont++;
          cout << "\n" << cont<< "      " <<listaOrdenada[i];
          if (cont == listaOrdenada.size()) break;
        }
      }
      if (orden == 2){
        for (int i = 0; i < cantResults; i++){
          cont++;
          cout << "\n" << cont<< "      " <<listaOrdenada[i];
        }
      }    
      awaitEnter();
    }
    else if( ans == 4){
       return;
    } 
    else if( ans == 0){
      cout << "\n=============== ¡ Opcion no valida ! ==============\n";
     break;
    } 
    else cout << "\n=============== ¡ Opcion no valida ! ==============\n------- Vuelva a ingresar la opcion deseada -------\n";
  }
}

//Complejidad : O(n*m)
void menuSearch(vector<string> linea1, SplayTree<int> &my_splay){
  //string ans = "";
  vector<string> sugerencias = {};
  cout << "\n==================================================="; 
  cout << "\n####%%#######################################%%####";
  cout << "\n###:.                                          .*##";
  cout << "\n#%-    🔍︎    Buscar jugador...                  .##";
  cout << "\n##%+..                                        .=%##";
  cout << "\n####%%#######################################%%####";
  cout << "\n===================================================\n"; 
  cout << "                          PARA CANCELAR INGRESE 4\n\n";
  cout << " Ingrese el nombre del jugador que desea buscar:  \n  ";
  char name[100]={0};
  cin.ignore();    
  cin.getline(name,100);
  string ans;
  ans += (string) name;
  if (ans == "4")return;
  else{
    cout << "\n\n        buscando coincidencias...           \n\n";
    sugerencias = my_splay.suggest(ans); //O(n*m)
    if (sugerencias.size() == 0){
      cout << "\n\n    No se encontraron coincidencias...\n\n";
      return;
    }
    else{
      float num;
      cout << "\n\n Existen "<< sugerencias.size() << " coincidencias: \n";
      for (int i= 0; i < sugerencias.size(); i++){
        cout << " "<< i+1 << ". " << sugerencias[i] << "\n";
      }
      cout << "\n\n Seleccione el numero de la coincidencia que desea buscar: \n  ";
      cin >> num;
      
      if (num <= sugerencias.size() && num >= 1){
        cout << "\n\n        realizando busqueda...              \n\n";
        int n = getStringValue(sugerencias[num-1]);
        string infoJugador = my_splay.find(n); //O(n)
        cout << "\n     Resultados obtenidos\n\n     La informacion del jugador será exportada a el archivo: \n             jugadoresBuscados.csv \n\n" ;
        awaitEnter();
        ofstream archivo;
        string nombreArchivo = "jugadoresBuscados.csv";
        // Abrimos el archivo
        archivo.open(nombreArchivo.c_str(), fstream::app);
        archivo << infoJugador;
        archivo << endl;
        // Finalmente lo cerramos
        archivo.close();

        nombreArchivo = "arbol.txt";
        // Abrimos el archivo
        archivo.open(nombreArchivo.c_str(), fstream::app);
        // Y le escribimos redirigiendo
        archivo << "\n\n ====================================================================================================";
        archivo << "\n\n\n\nVersion busqueda " << sugerencias[num-1] << ": \n" ;
        stringstream arbolPrinted = my_splay.printTree();
        archivo << arbolPrinted.str();
        archivo << endl;
        // Finalmente lo cerramos
        archivo.close();
      }
      else {
        cout << "\n=============== ¡ Opcion no valida ! ==============\n";
        return;
      }
      
    } 
  }

  
}
  


//Complejidad : O(n^2)
void menu(ifstream& inFile, Sorts<int> sorts, vector<string> linea1, vector<string> nombres, int numLines, SplayTree<int> &my_splay ){
  float ans = 1;
  while (ans != 3){

    cout << "\n\n======================= MENU ======================\n";
    cout << "\n===================================================\n";
    cout << "\n===           1. Estadisticas                   ===\n";
    cout << "\n===           2. Buscar Jugador                 ===\n";
    cout << "\n===           3. Cerrar Aplicacion              ===\n";
    cout << "\n===                                             ===\n";
    cout << "\n===================================================\n\n"; 
    cin >> ans;
    if( ans == 1){
      menuStats(inFile, sorts,linea1, nombres, numLines);
    }    
    else if( ans == 2){
      menuSearch(linea1,my_splay);
    }     
    else if( ans == 3){
      cout << "\n   Cerrando aplicacion...\n";
    } 
    else if( ans == 0){
      cout << "\n=============== ¡ Opcion no valida ! ==============\n";
     break;
    } 
    else cout << "\n=============== ¡ Opcion no valida ! ==============\n------- Vuelva a ingresar la opcion deseada -------\n";
  }
}

//Complejidad : O(n^2)
int main() {
  Sorts<int> sorts;
  ifstream inFile;
	inFile.open("england-premier-league-players-2018-to-2019-stats.csv");
  //Obtener cantidad de lineas en archivo
  int numLines = 0;
  string unused;
  while ( std::getline(inFile, unused) )
     ++numLines;
  inFile.clear();
  inFile.seekg(0); // posicionar de nueva al inicio del archivo
	//obtener linea 1
	vector<string> linea1 = getLineSep(inFile,0,1);
  vector<string> nombres = getColumn(inFile, 1, numLines, 0); //obtener lista de nombres de jugadores
  // cargar estructura de datos:arbol splay
  inFile.clear();
  inFile.seekg(0);
  SplayTree<int> my_splay;
  string lineaJugador;
  int valorNombre;
  getline(inFile,lineaJugador);//posicionar en linea2
  for (int i = 0; i < numLines-1; i++){
    getline(inFile,lineaJugador);
    valorNombre = getStringValue(nombres[i]);
    my_splay.add(valorNombre,nombres[i], lineaJugador);
  }
  string nombreArchivo = "arbol.txt";
  ofstream archivo;
  // Abrimos el archivo
  archivo.open(nombreArchivo.c_str(), fstream::out);
  // Y le escribimos redirigiendo
  archivo << "Version Inicial\n";
  stringstream arbolPrinted = my_splay.printTree();
  archivo << arbolPrinted.str();
  archivo << endl;
  // Finalmente lo cerramos
  archivo.close();


  
  nombreArchivo = "jugadoresBuscados.csv";
  // Abrimos el archivo
  archivo.open(nombreArchivo.c_str(), fstream::out);
  // Y le escribimos redirigiendo
  for (int i = 0; i < linea1.size(); i++){
    archivo << linea1[i] <<", ";
  }
  archivo << endl;
  // Finalmente lo cerramos
  archivo.close();
  
  //my_splay.printTree()
  menu(inFile, sorts,linea1, nombres, numLines, my_splay);

}