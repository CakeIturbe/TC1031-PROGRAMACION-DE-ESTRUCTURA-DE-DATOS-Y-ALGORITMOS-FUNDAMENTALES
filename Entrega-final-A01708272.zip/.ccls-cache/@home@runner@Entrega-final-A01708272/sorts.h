/*
 * sorts.h
 *
 *  Created on: 28/08/2023
 *      Author: DIEGO ITURBE BRAVO
 */

#ifndef SORTS_H_
#define SORTS_H_

#include "exception.h"
#include <vector>
#include <list>

template <class T>
class Sorts {
private:
	void swap(std::vector<T>&, int, int);
  void swapString(std::vector<std::string>&, int, int);
public:
	std::vector<std::string> bubbleSort(const std::vector<T>&,const std::vector<std::string>&);
};

//Complejidad : O(1)
template <class T>
void Sorts<T>::swap(std::vector<T> &v, int i, int j) {
	T aux = v[i];
	v[i] = v[j];
	v[j] = aux;
}

//Complejidad : O(1)
template <class T>
void Sorts<T>::swapString(std::vector<std::string> &v, int i, int j) {
  std::string aux = v[i];
  v[i] = v[j];
  v[j] = aux;
}

//Complejidad : O(n^2)
template <class T>
std::vector<std::string> Sorts<T>::bubbleSort(const std::vector<T> &source, const std::vector<std::string> &source2) {
	std::vector<T> v(source);
  std::vector<std::string> v2(source2);
	for (int i = v.size() - 1; i > 0; i--) {
		for (int j = 0; j < i; j++) {
			if (v[j] > v[j + 1]) {
				swap(v, j, j + 1);
        swapString(v2, j, j + 1);
			}
		}
	}
	return v2;
}

#endif /* SORTS_H_ */
